import { Component,ViewChild ,ChangeDetectorRef} from '@angular/core';
import {MatTableDataSource, MatPaginator } from '@angular/material';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  gallery:any=[{"id":1,"img":"assets/contact1.jpg","model":"firstImg"},
              {"id":2,"img":"assets/flower.jpg","model":"secondImg"},
              {"id":3,"img":"assets/conttact.jpg","model":"thirdImg"},
              {"id":4,"img":"assets/animal.jpeg","model":"fourthtImg"},
              {"id":5,"img":"assets/animal1.jpg","model":"fifthImg"},
              {"id":6,"img":"assets/animal2.jpg","model":"sixImg"},
              {"id":7,"img":"assets/contact1.jpg","model":"firstImg1"},
              {"id":8,"img":"assets/flower.jpg","model":"secondImg1"},
              {"id":9,"img":"assets/conttact.jpg","model":"thirdImg1"},
              {"id":10,"img":"assets/animal.jpeg","model":"fourthtImg1"},
              {"id":11,"img":"assets/animal1.jpg","model":"fifthImg1"},
              {"id":12,"img":"assets/animal2.jpg","model":"sixImg1"},]


  title = 'galleryApp';
  currentRecord:any=[];
  currentRecord1:any=[];
  currentContact:any={};
   index:number= 0;
   flagPrev:boolean=true;
   flagNext:boolean=true;
 imageToShow:any = '';
 id:number;
 img: any;
 model: any; 
 dataSource =  new MatTableDataSource(this.gallery); 
 @ViewChild(MatPaginator,{static: true}) paginator: MatPaginator; 
 obs: Observable<any>;
 constructor(private changeDetectorRef: ChangeDetectorRef){}
 ngOnInit() {
  this.dataSource.paginator = this.paginator;
  this.changeDetectorRef.detectChanges();
  this.dataSource.paginator = this.paginator;
  this.obs = this.dataSource.connect();
  };
  
  switchStyle(galleryUnit){
    this.id =galleryUnit.id;
    this.img=galleryUnit.img;
    this.model =galleryUnit.model; 
    this.index=this.gallery.findIndex( res => res.id === this.id);
    if( this.index == 0){
      this.flagPrev = false;
    }
    else{
      this.flagPrev = true;
    }
    if( this.index == (this.gallery.length)-1){
      this.flagNext = false;
    }
    else{
        this.flagNext = true;
    }
    
  }
  prev(){
   this.index=this.gallery.findIndex( res => res.id === this.id);
   this.currentRecord =  this.gallery[this.index-1] ;
   this.id = this.currentRecord.id;
   this.img= this.currentRecord.img;
   this.model = this.currentRecord.model; 
   if( this.index == 1){
    this.flagPrev = false;
  }
  
  if( this.index == this.gallery.length){
    this.flagNext = false;
  }
  this.flagNext = true;
  } 

next() {
  this.index=this.gallery.findIndex( res => res.id === this.id);
    this.currentRecord =  this.gallery[this.index+1] ;
    this.id = this.currentRecord.id;
    this.img= this.currentRecord.img;
    this.model = this.currentRecord.model; 

  if( this.index == (this.gallery.length)-2){
    this.flagNext = false;
  }
  this.flagPrev = true;
}
}

